/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
unsigned char maled_duoi[27][8] = {0x00,0x3c,0x24,0x24,0x24,0x24,0x3c,0x00,  //0
																	 0x00,0x08,0x18,0x28,0x08,0x08,0x08,0x00,  //1
																   0x00,0x38,0x04,0x08,0x10,0x20,0x3c,0x00,  //2    
																	 0x00,0x3c,0x04,0x3c,0x04,0x04,0x3c,0x00,  //3
																	 0x00,0x24,0x24,0x3c,0x04,0x04,0x04,0x00,  //4
																	 0x00,0x3c,0x20,0x3c,0x04,0x04,0x3c,0x00,  //5
																	 0x00,0x3c,0x20,0x3c,0x24,0x24,0x3c,0x00,  //6
																	 0x00,0x3c,0x04,0x04,0x04,0x04,0x04,0x00,  //7
																	 0x00,0x3c,0x24,0x3c,0x24,0x24,0x3c,0x00,  //8
																	 0x00,0x3c,0x24,0x3c,0x04,0x04,0x3c,0x00,  //9
                                   0x00,0x00,0x11,0x2a,0x44,0x00,0x00,0x00,   //dau  ng� ~
																	 0x00,0x08,0x08,0x08,0x08,0x00,0x08,0x00,   //dau cham than ! 
																	 0x00,0x3c,0x42,0x9d,0xa5,0xa5,0x5e,0x20,   // dau @
																	 0x00,0x24,0x7e,0x24,0x24,0x7e,0x24,0x00,   // dau # 
																	 0x08,0x1c,0x20,0x38,0x04,0x04,0x38,0x08,   // dau $
																	 0x31,0x32,0x04,0x08,0x10,0x26,0x46,0x80,   // dau %
																	 0x00,0x00,0x00,0x18,0x24,0x42,0x81,0x00,   //dau ^
																	 0x00,0x18,0x24,0x18,0x39,0x46,0x46,0x39,   //dau &
																	 0x00,0x92,0x54,0x38,0xfe,0x38,0x54,0x92,   //dau *
																	 0x0c,0x12,0x02,0x04,0x08,0x00,0x08,0x00,   // dau ?
																	 0x00,0x02,0x04,0x08,0x10,0x20,0x40,0x00,   // dau /
																	 0x00,0x10,0x10,0x7c,0x10,0x10,0x00,0x00,   // dau +
																	 0x00,0x00,0x7e,0x00,0x00,0x7e,0x00,0x00,   // dau =
																	 0x00,0x00,0x08,0x00,0x00,0x0c,0x04,0x08,   // dau ;
																	 0x00,0x10,0x20,0x40,0x40,0x40,0x20,0x10,   // dau ngoac don (
																	 0x00,0x10,0x20,0x20,0x40,0x20,0x20,0x10,   // dau ngoac kep {
																	 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; //clear
unsigned char maled_tren[8] = {~(0x01),~(0x02),~(0x04),~(0x08),~(0x10),~(0x20),~(0x40),~(0x80)};


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */
void CLOCK_74HC594()
{
	GPIOA->ODR&=~(1<<0); //MUC 0  OUTPUT PA0
	GPIOA->ODR|= (1<<0);  //MUC 1
}
void LATH_74HC594()
{
	GPIOA->ODR|=(1<<1);  //MUC 1 OUTPUT PA1
	GPIOA->ODR&=~(1<<1); //MUC 0
}
void data_tren(int n)        // m la hien thi so 0 la 0 
{
		for(char i=0;i<8;i++)
		{
			 if((n&(1<<(7-i)))==0)
			 {
				 GPIOA->ODR&=~(1<<2);  //OUTPUT PA2
				 CLOCK_74HC594();
			 }
			 else 
			 {
				 GPIOA->ODR|=(1<<2);
				 CLOCK_74HC594();
			 } 
		}
	
}
void data_duoi(int m)
{
	for(char i=0;i<8;i++)
		{
			 if((m &(1<<(7-i)))==0)
			 {
				 GPIOA->ODR&=~(1<<2);  //OUTPUT PA2
				 CLOCK_74HC594();
			 }
			 else 
			 {
				 GPIOA->ODR|=(1<<2);
				 CLOCK_74HC594();
			 } 
		}
		
}
void clear()
{
	   for(int i= 0 ; i<8;i++){                                                             
		 data_duoi(maled_duoi[26][i]);
		 data_tren(maled_tren[i]);
		 LATH_74HC594();
		 HAL_Delay(2);
		}
}
void test()
{
	
	   //sang so 0 
	   for(int i = 0 ; i <100;i++){    //time delay
		 data_duoi(maled_duoi[0][0]);
		 data_tren(maled_tren[0]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[0][1]);
		 data_tren(maled_tren[1]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[0][2]);
		 data_tren(maled_tren[2]);
		 LATH_74HC594();
		 HAL_Delay(2);
     data_duoi(maled_duoi[0][3]);
		 data_tren(maled_tren[3]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[0][4]);
		 data_tren(maled_tren[4]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[0][5]);
		 data_tren(maled_tren[5]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[0][6]);
		 data_tren(maled_tren[6]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[0][7]);
		 data_tren(maled_tren[7]);
		 LATH_74HC594();
		 HAL_Delay(2);}
		 clear();
		 HAL_Delay(50);
		 
		 //sang so 1 
		 for(int i = 0 ; i <100;i++){
		 data_duoi(maled_duoi[1][0]);
		 data_tren(maled_tren[0]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[1][1]);
		 data_tren(maled_tren[1]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[1][2]);
		 data_tren(maled_tren[2]);
		 LATH_74HC594();
		 HAL_Delay(2);
     data_duoi(maled_duoi[1][3]);
		 data_tren(maled_tren[3]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[1][4]);
		 data_tren(maled_tren[4]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[1][5]);
		 data_tren(maled_tren[5]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[1][6]);
		 data_tren(maled_tren[6]);
		 LATH_74HC594();
		 HAL_Delay(2);
		 data_duoi(maled_duoi[1][7]);
		 data_tren(maled_tren[7]);
		 LATH_74HC594();
		 HAL_Delay(2);}
		 clear();
		 HAL_Delay(50);
}
void display()
{
	  for(int m = 0 ; m <26;m++){     // 26 so + ki tu 
		for(int j = 0 ; j<100;j++){    // time delay
		for(int i= 0 ; i<8;i++){                                                             //sang tung so 
		 data_duoi(maled_duoi[m][i]);
		 data_tren(maled_tren[i]);
		 LATH_74HC594();
		 HAL_Delay(2);
		}
	}//end time_delay
		clear();
		HAL_Delay(50);
}//end 26 so+kitu
	
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */
  RCC->APB2ENR|=(1<<2);   // GPIOA KICH HOAT
	GPIOA->CRL= 0x00000000;
	GPIOB->CRL = 0x00000000;
  GPIOA->CRL|=(1<<0)|(1<<4)|(1<<8);   // OUTPUT PA0 toi PA2
	
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	  display();
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
